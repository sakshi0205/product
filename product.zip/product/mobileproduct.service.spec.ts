import { TestBed } from '@angular/core/testing';

import { MobileproductService } from './mobileproduct.service';

describe('MobileproductService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MobileproductService = TestBed.get(MobileproductService);
    expect(service).toBeTruthy();
  });
});
