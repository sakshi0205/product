import { Productdata } from './productdata';

describe('Productdata', () => {
  it('should create an instance', () => {
    expect(new Productdata()).toBeTruthy();
  });
});
