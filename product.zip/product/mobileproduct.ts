export interface Mobileproduct {
    id: number;
    name: string;
    description: string;
    price: number;
  }