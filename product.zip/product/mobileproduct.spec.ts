import { Mobileproduct } from './mobileproduct';

describe('Mobileproduct', () => {
  it('should create an instance', () => {
    expect(new Mobileproduct()).toBeTruthy();
  });
});
