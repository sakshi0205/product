import { Component, OnInit } from '@angular/core';
import { Mobileproduct } from '../mobileproduct';
import { clone } from 'lodash';
import { MobileproductService } from '../mobileproduct.service';

@Component({
  selector: 'app-mobileproduct',
  templateUrl: './mobileproduct.component.html',
  styleUrls: ['./mobileproduct.component.css']
})
export class MobileproductComponent implements OnInit {
  products: Mobileproduct[];
  productForm: boolean = false;
  editProductForm: boolean = false;
  isNewForm: boolean;
  newProduct: any = {};
  editedProduct: any = {};

  constructor(private _mobileproduct: MobileproductService) { }

  ngOnInit() {
    this.getProducts();
  }

  getProducts() {
    this.products = this._mobileproduct.getProductsFromData();
  }

  showEditProductForm(product: Mobileproduct) {
    if(!product) {
      this.productForm = false;
      return;
    }
    this.editProductForm = true;
    this.editedProduct = clone(product);
  }

  showAddProductForm() {
    // resets form if edited product
    if(this.products.length) {
      this.newProduct = {};
    }
    this.productForm = true;
    this.isNewForm = true;
  }

  saveProduct(product: Mobileproduct) {
    if(this.isNewForm) {
      // add a new product
      this._mobileproduct.addProduct(product);
    }
    this.productForm = false;
  }

  removeProduct(product: Mobileproduct) {
    this._mobileproduct.deleteProduct(product);
  }

  updateProduct() {
    this._mobileproduct.updateProduct(this.editedProduct);
    this.editProductForm = false;
    this.editedProduct = {};
  }

  cancelNewProduct() {
    this.newProduct = {};
    this.productForm = false;
  }

  cancelEdits() {
    this.editedProduct = {};
    this.editProductForm = false;
  }

}

