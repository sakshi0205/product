import { Injectable } from '@angular/core';
import { Mobileproduct } from './mobileproduct';
import { PRODUCT_ITEMS } from './productdata';
import { findIndex } from 'lodash';


@Injectable({
  providedIn: 'root'
})
export class MobileproductService {

  private pItems = PRODUCT_ITEMS;

  getProductsFromData(): Mobileproduct[] {
    console.log(this.pItems);
    return this.pItems
  }

  addProduct(product: Mobileproduct) {
    this.pItems.push(product);
    console.log(this.pItems);
  }

  updateProduct(product: Mobileproduct) {
    let index = findIndex(this.pItems, (p: Mobileproduct) => {
      return p.id === product.id;
    });
    this.pItems[index] = product;
  }

  deleteProduct(product: Mobileproduct) {
    this.pItems.splice(this.pItems.indexOf(product), 1);
    console.log(this.pItems);
  }

}

  // getProductsFromService(): Product[] {
  //   return [{
  //   id: 1,
  //   name: 'Scissors',
  //   description: 'use this to cut stuff',
  //   price: 4.99
  // }, {
  //   id: 2,
  //   name: 'Steak Knives',
  //   description: 'use this to eat food with',
  //   price: 10.99
  // }, {
  //   id: 3,
  //   name: 'Shot Glass',
  //   description: 'use this to take shots',
  //   price: 5.99
  // }]
  // }
